<html>
    <body>
        <?php
            echo "O valor de campo 1 é: " . $_POST["campo1"];
            echo "<br>O valor de campo 2 é: " . $_POST["campo2"];

        ?>    
    </body>
</html>
