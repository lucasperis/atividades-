<html>
    <body>
        <?php
            $cont = 200;

            do{

                $dobro = $cont + $cont;
                echo "O drobro de $cont é $dobro";
                $cont++;

            }while ($cont<= 1999);  

         
         

         ?>   
    </body>
</html>