 <html>
    <body>
        <form id="formacadastro" nome="formcadastro" method="POST" action= "recebeform.php"

      
        campo 1: <input type=text name=campo1><br>
        campo 2: <input type=text nome=campo2><br>


        <input id="botaoeviar" type="submit" value="enviar">
</form>

    </body>
 </html>