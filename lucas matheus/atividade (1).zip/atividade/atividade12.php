<HTml>
    <BOdy>
        <?php
            $NUM = 0;
            while ($NUM < 10 ) {
            echo $num++;   # code...
            }


        ?>    
    </BOdy>
</HTml>
